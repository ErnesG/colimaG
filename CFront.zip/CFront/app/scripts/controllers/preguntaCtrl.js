'use strict';


angular.module('cfrontApp').controller('preguntaCtrl', ['$scope','dataFactory',function($scope,dataFactory){

 $scope.preg=
 {


  descripcion:'',
  latitud:19.4873,
  longitud:-99.1548,
  urlvideo:'',
  nombre:'',
  email:'',
  telefono:'',
  contmail:true,
  conttelefono:false,
  contambos:false
 };
 $scope.categorias=[];

 $scope.contTel=function(){
   $scope.preg.contmail=false;
   $scope.preg.conttelefono=true;
   $scope.preg.contambos=false;
 };
 $scope.contMail=function(){
   $scope.preg.contmail=true;
   $scope.preg.conttelefono=false;
   $scope.preg.contambos=false;
 };
 $scope.contA=function(){
   $scope.preg.contmail=false;
   $scope.preg.conttelefono=false;
   $scope.preg.contambos=true;
 };
 $scope.send=function(){

  dataFactory.preguntar($scope.preg)
  .success(function(){
    $scope.preg={};
  })
  .error(function(error) {

          });
 };




}]);
