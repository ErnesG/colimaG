'use strict';

angular.module('cfrontApp').controller('participacionesCtrl', ['$scope','dataFactory',function($scope,dataFactory){

  $scope.part=[];
  //listado de reportes
  $scope.brigAllReports=function(){
    dataFactory.getReports()
    .success(function(res){
      $scope.part=res;
    })
    .error(function (error) {
           $scope.status = 'Error: ' + error.message;
     });
  };
  $scope.brigAllReports();
}]);
