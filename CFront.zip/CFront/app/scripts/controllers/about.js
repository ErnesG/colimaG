'use strict';

/**
 * @ngdoc function
 * @name cfrontApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the cfrontApp
 */
angular.module('cfrontApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
