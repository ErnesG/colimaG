'use strict';

  angular.module('cfrontApp').factory('dataFactory',['$http',function($http){
    var baseUrl='http://127.0.0.1:8000/colimaApp/';
    var mapsURL="https://maps.googleapis.com/maps/api/geocode/json?latlng=";

    var dataFactory={};
    dataFactory.getParsedAdd=function(lat,long){
      return $http.get(mapsURL+lat+','+long+'&key=AIzaSyBlKYTsEbvJVj8oZsDTbnCNwmUO_h_KFyU');
    };
    dataFactory.getEstadisticas=function(){
      return $http.get(baseUrl+'estadisticas');
    };
    dataFactory.getReports=function(){
      return $http.get(baseUrl+'reportes');
    };
    dataFactory.getPreguntas=function(){
      return $http.get(baseUrl+'preguntas');

    };
    dataFactory.getCategorias=function(){
      return $http.get(baseUrl+'categorias');
    };
    dataFactory.login=function(user){
      return $http.post(baseUrl+'login',user);
    };
    dataFactory.preguntar=function(pregunta){
      return $http.post(baseUrl+'preguntar/',pregunta);
    };
    dataFactory.reportar=function(r){
      return $http.post(baseUrl+'reportar/',r);
    };
    dataFactory.crearCategoria=function(c){
      return $http.post(baseUrl+'addCategory',c);
    };
    dataFactory.updateQ=function(pregunta){
      return $http.post(baseUrl+'updateQuestion',pregunta);
    };
    dataFactory.updateR=function(r){
      return $http.post(baseUrl+'updateReport',r);
    };
    dataFactory.deleteQ=function(idq){
      return $http.get(baseUrl+'borraP/'+idq);
    };
    dataFactory.deleteR=function(idr){
      return $http.get(baseUrl+'borraR/'+idr);
    };
    dataFactory.findR=function(idr){
      return $http.get(baseUrl+'findReport/'+idr);
    };
    return dataFactory;




  }]);
