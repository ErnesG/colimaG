'use strict';


angular.module('cfrontApp').controller('MainCtrl', ['$scope','dataFactory',function($scope,dataFactory){
      $scope.est;
      $scope.status;
      $scope.part=[];
      $scope.parsedPart=[];
      $scope.puntos=[];
      var mape,marker;


      $scope.estf=function estadistics(){
        dataFactory.getEstadisticas()
         .success(function(res){
           $scope.est=res;
         })
         .error(function (error) {
                $scope.status = 'Error: ' + error.message;
          });
      };
      $scope.estf();
      $scope.$on('mapInitialized',function(evt,evtMap){
        mape=evtMap;
        $scope.bringP=function(){
          dataFactory.getReports()
          .success(function(res){
            $scope.part=res;
             for(var i=0;i<$scope.part.length;i++){
               var point={lat:$scope.part[i].latitud, lng:$scope.part[i].longitud};
               marker=new google.maps.Marker({
                 position:point,
                 map:mape
               });




             }

          })
          .error(function (error) {
                 $scope.status = 'Error: ' + error.message;
           });
        };
        $scope.bringP();

      });




    }]);
