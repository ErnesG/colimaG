'use strict';


angular.module('cfrontApp').controller('propuestaCtrl', ['$scope','dataFactory',function($scope,dataFactory){

 $scope.reporte=
 {
  tipopart:1,
  categoria:1,
  descripcion:'',
  latitud:19.4893,
  longitud:-99.1546,
  urlvideo:'',
  nombre:'',
  email:'',
  telefono:'',
  contmail:true,
  conttelefono:false,
  contambos:false
 };
 $scope.categorias=[];
 $scope.setTipoP=function(tp){
   $scope.reporte.tipopart=tp;

 };
 $scope.contTel=function(){
   $scope.reporte.contmail=false;
   $scope.reporte.conttelefono=true;
   $scope.reporte.contambos=false;
 };
 $scope.contMail=function(){
   $scope.reporte.contmail=true;
   $scope.reporte.conttelefono=false;
   $scope.reporte.contambos=false;
 };
 $scope.contA=function(){
   $scope.reporte.contmail=false;
   $scope.reporte.conttelefono=false;
   $scope.reporte.contambos=true;
 };
 $scope.send=function(){
  console.log($scope.reporte.categoria);
  dataFactory.reportar($scope.reporte)
  .success(function(){
    $scope.reporte={};
  })
  .error(function(error) {
                $scope.status = 'Unable to insert ' + error.message;
          });
 };
 $scope.loadCategs=function() {
   // body...
   dataFactory.getCategorias()
   .success(function(res){
     $scope.categorias=res;
   })
   .error(function (error) {
          $scope.status = 'Error: ' + error.message;
    });
 };
 $scope.loadCategs();



}]);
