'use strict';


 (function(){
   var colima=angular
     .module('cfrontApp',['ngAnimate','ngAria','ngCookies','ngMessages',
     'ngResource','ngRoute','ngSanitize','ngTouch','ui.bootstrap','ngMap']);

     colima.config(function ($routeProvider) {
       $routeProvider
         .when('/', {
           templateUrl: 'views/main.html',
           controller: 'MainCtrl',
           controllerAs: 'main'
         })
         .when('/about', {
           templateUrl: 'views/about.html',
           controller: 'AboutCtrl',
           controllerAs: 'about'
         })
         .when('/propuesta',{
           templateUrl:'views/nuevaPropuesta.html',
           controller:'propuestaCtrl',
           controllerAs:'proctrl'

         })
         .when('/pregunta',{
           templateUrl:'views/nuevaPregunta.html',
           controller:'preguntaCtrl',
           controllerAs:'qCtrl'

         })
         .when('/participaciones',{
           templateUrl:'views/listadoReportes.html',
           controller:'participacionesCtrl',
           controllerAs:'reportesCtrl'

         })
         .otherwise({
           redirectTo: '/'
         });
     });


 })();
